"use strict";

var _wp$data = wp.data,
  useSelect = _wp$data.useSelect,
  useDispatch = _wp$data.useDispatch;
var _wp$blockEditor = wp.blockEditor,
  PanelBody = _wp$blockEditor.PanelBody,
  MediaUpload = _wp$blockEditor.MediaUpload,
  MediaUploadCheck = _wp$blockEditor.MediaUploadCheck;
wp.blocks.registerBlockVariation("core/group", {
  name: "full-width-group",
  title: "Full width group",
  attributes: {
    align: "full"
  }
});

// block-extensions.js

function BackgroundImagePanel(_ref) {
  var clientId = _ref.clientId;
  var block = useSelect(function (select) {
    return select("core/block-editor").getBlockAttributes(clientId);
  }, [clientId]);
  var dispatch = useDispatch("core/block-editor");
  function setImage(attributes) {
    dispatch.updateBlockAttributes(clientId, attributes);
  }
  function removeImage() {
    setImage({
      backgroundImageId: undefined
    });
  }
  function onUpdateImage(newImage) {
    setImage({
      backgroundImageId: newImage.id,
      backgroundImage: newImage.url
    });
  }
  return /*#__PURE__*/React.createElement(PanelBody, {
    title: "Background Image"
  }, /*#__PURE__*/React.createElement(MediaUploadCheck, null, /*#__PURE__*/React.createElement(MediaUpload, {
    onSelect: onUpdateImage,
    allowedTypes: "image",
    render: function render(_ref2) {
      var open = _ref2.open;
      return /*#__PURE__*/React.createElement("div", null, block.backgroundImage && /*#__PURE__*/React.createElement("img", {
        src: block.backgroundImage
      }), /*#__PURE__*/React.createElement("button", {
        onClick: open
      }, "Set background image"), block.backgroundImage && /*#__PURE__*/React.createElement("button", {
        onClick: removeImage
      }, "Remove background image"));
    }
  })));
}
wp.hooks.addFilter("editor.BlockEdit", "mytheme/block-extensions", wp.compose.createHigherOrderComponent(function (BlockEdit) {
  return function (props) {
    var name = props.name,
      clientId = props.clientId;
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(BlockEdit, props), name === "core/paragraph" ? /*#__PURE__*/React.createElement(BackgroundImagePanel, {
      clientId: clientId
    }) : null);
  };
}, "withInspectorControls"));
