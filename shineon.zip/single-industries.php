<!-- wp:post-title /-->
<!-- wp:post-content /-->
<!-- wp:html -->
<?php
    if (have_posts()) :
        while (have_posts()) : the_post();
            $points_heading = get_field('points_heading');
            $points_details = get_field('points_details');

            echo '<div>';
            echo '<h2>' . $points_heading . '</h2>';
            echo '<p>' . $points_details . '</p>';
            echo '</div>';
        endwhile;
    endif;
    ?>
<!-- /wp:html -->


<?php
// Get the current user's ID
$current_user_id = get_current_user_id();
// Get the SEO reports for the current user
$seo_reports = get_field("seo_reports", "user_" . $current_user_id);
// Check if SEO reports exist for the current user
if ($seo_reports) {
    echo '<div class="as-repeater-fields"> ';
    foreach ($seo_reports as $seo_report) {
        $report_data = $seo_report["report_data"];
        $title = $seo_report["title"];
        $detail = $seo_report["detail"];
        $images_gallery = $seo_report["images_gallery"];
        $pdf_link = $seo_report["pdf_link"];

        // Check if the report_data field has content before displaying it
        echo '<div class="as-repeater-field as-services-div"> ';
        if (!empty($report_data)) {
            echo '<p class=" as-blue-color"> ' .
                esc_html($report_data) .
                "</p>";
        }
        echo '<div class="as-repeater-image"> ';
        // Loop through and display images from the images_gallery field if it's not empty
        if (!empty($images_gallery)) {
            echo '<div class="image-gallery">';
            foreach ($images_gallery as $image): ?>
<a href="<?php echo esc_url($image["url"]); ?>" class="lightbox-trigger">
    <img src="<?php echo esc_url($image["url"]); ?>" alt="<?php echo esc_attr(
    $image["alt"]
); ?>" />
</a>
<?php endforeach;
            echo "</div>";
        }
        echo "</div>";
        echo '<div class="as-repeater-content"> ';
        // Check if the title field has content before displaying it
        if (!empty($title)) {
            echo '<h2 class="as-reachly-h2">  ' . esc_html($title) . "</h2>";
        }
        // Check if the detail field has content before displaying it
        if (!empty($detail)) {
            echo '<p class="as-body-text" >  ' .
                html_entity_decode($detail) .
                "</p>";
        }
        // Check if the pdf_link field has content before displaying it
        if (!empty($pdf_link)) {
            echo '<p>  <a class="as-reacly-cta" href="' .
                esc_url($pdf_link) .
                '" target="_blank" >Download PDF</a></p>';
        }
        echo "</div>";
    }
    echo "</div>";
    echo "</div>";
} else {
    echo "No SEO reports found for the current user.";
}
?>