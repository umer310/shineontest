// // const { useSelect, useDispatch } = wp.data;
// // const { PanelBody, MediaUpload, MediaUploadCheck } = wp.blockEditor;
// // wp.blocks.registerBlockVariation("core/group", {
// // 	name: "full-width-group",
// // 	title: "Full width group",
// // 	attributes: {
// // 		align: "full",
// // 	},
// // });

// // // block-extensions.js

// // function BackgroundImagePanel({ clientId }) {
// // 	const block = useSelect(
// // 		(select) => select("core/block-editor").getBlockAttributes(clientId),
// // 		[clientId]
// // 	);
// // 	const dispatch = useDispatch("core/block-editor");

// // 	function setImage(attributes) {
// // 		dispatch.updateBlockAttributes(clientId, attributes);
// // 	}

// // 	function removeImage() {
// // 		setImage({ backgroundImageId: undefined });
// // 	}

// // 	function onUpdateImage(newImage) {
// // 		setImage({
// // 			backgroundImageId: newImage.id,
// // 			backgroundImage: newImage.url,
// // 		});
// // 	}

// // 	return (
// // 		<PanelBody title="Background Image">
// // 			<MediaUploadCheck>
// // 				<MediaUpload
// // 					onSelect={onUpdateImage}
// // 					allowedTypes={"image"}
// // 					render={({ open }) => (
// // 						<div>
// // 							{block.backgroundImage && <img src={block.backgroundImage} />}
// // 							<button onClick={open}>Set background image</button>
// // 							{block.backgroundImage && (
// // 								<button onClick={removeImage}>Remove background image</button>
// // 							)}
// // 						</div>
// // 					)}
// // 				/>
// // 			</MediaUploadCheck>
// // 		</PanelBody>
// // 	);
// // }

// // wp.hooks.addFilter(
// // 	"editor.BlockEdit",
// // 	"mytheme/block-extensions",
// // 	wp.compose.createHigherOrderComponent(
// // 		(BlockEdit) => (props) => {
// // 			const { name, clientId } = props;

// // 			return (
// // 				<div>
// // 					<BlockEdit {...props} />
// // 					{name === "core/paragraph" ? (
// // 						<BackgroundImagePanel clientId={clientId} />
// // 					) : null}
// // 				</div>
// // 			);
// // 		},
// // 		"withInspectorControls"
// // 	)
// // );
// const { registerBlockType } = wp.blocks;
// const { InspectorControls } = wp.blockEditor;
// const { PanelBody, TextControl } = wp.components;

// wp.domReady(function () {
// 	wp.hooks.addFilter(
// 		"editor.BlockEdit",
// 		"_themename/with-inspector-controls",
// 		withInspectorControls
// 	);

// 	function withInspectorControls(BlockEdit) {
// 		return (props) => {
// 			return (
// 				<Fragment>
// 					<BlockEdit {...props} />
// 					<InspectorControls>
// 						<PanelBody>
// 							<TextControl
// 								label="Extra CSS Class"
// 								value={props.attributes.extraCustomClass}
// 								onChange={(extraCustomClass) =>
// 									props.setAttributes({ extraCustomClass })
// 								}
// 							/>
// 						</PanelBody>
// 					</InspectorControls>
// 				</Fragment>
// 			);
// 		};
// 	}
// });
