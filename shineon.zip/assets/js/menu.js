function addContanerAfter() {
	const expandableItems = document.querySelectorAll("li[aria-expanded]");

	// Loop through each expandable item
	expandableItems.forEach((item) => {
		const isExpanded = item.getAttribute("aria-expanded") === "true";

		if (isExpanded) {
			// Create a div element
			const divElement = document.createElement("div");
			divElement.classList.add("submenu-container");

			// Wrap the item's child ul with the div
			const ulElement = item.querySelector("ul");
			if (ulElement) {
				item.replaceChild(divElement, ulElement);
				divElement.appendChild(ulElement);
			}
		}
	});
}

document.addEventListener("DOMContentLoaded", function () {
	const tabTitles = document.querySelectorAll(".my-tab > a ");
	const tabContentItems = document.querySelectorAll(".depth-1 > ul.sub-menu");
	console.log(tabTitles);
	tabTitles.forEach((title, index) => {
		// Add 'open' class to the first tab title and content item
		tabTitles[0].classList.add("active");
		tabContentItems[0].classList.add("active");
		title.addEventListener("click", () => {
			// Remove 'active' class from all tab titles and content items
			tabTitles.forEach((tabTitle) => tabTitle.classList.remove("active"));
			tabContentItems.forEach((content) => content.classList.remove("active"));

			// Add 'active' class to the clicked tab title and corresponding content item
			title.classList.add("active");
			tabContentItems[index].classList.add("active");
		});
	});
});

// Get all ul elements with the class "sub-menu"
const subMenus = document.querySelectorAll(".my-submenu-container > ul");

// Loop through each ul element
subMenus.forEach((ul) => {
	// Create a new div element
	const divElement = document.createElement("div");
	divElement.classList.add("submenu-container");

	// Wrap the ul element with the div
	ul.parentNode.insertBefore(divElement, ul);
	divElement.appendChild(ul);
});

var appsMenuItems = document.querySelectorAll("#menu-menu-1 > li");
var subMenuItems = document.querySelectorAll("#menu-menu-1 > li li");
var keys = {
	tab: 9,
	enter: 13,
	esc: 27,
	space: 32,
	left: 37,
	up: 38,
	right: 39,
	down: 40,
};
var currentIndex, subIndex;

var gotoIndex = function (idx) {
	if (idx == appsMenuItems.length) {
		idx = 0;
	} else if (idx < 0) {
		idx = appsMenuItems.length - 1;
	}
	appsMenuItems[idx].focus();
	currentIndex = idx;
};

var gotoSubIndex = function (menu, idx) {
	var items = menu.querySelectorAll("li");
	if (idx == items.length) {
		idx = 0;
	} else if (idx < 0) {
		idx = items.length - 1;
	}
	items[idx].focus();
	subIndex = idx;
};

Array.prototype.forEach.call(appsMenuItems, function (el, i) {
	if (0 == i) {
		el.setAttribute("tabindex", "0");
		el.addEventListener("focus", function () {
			currentIndex = 0;
		});
	} else {
		el.setAttribute("tabindex", "-1");
	}
	el.addEventListener("focus", function () {
		subIndex = 0;
		Array.prototype.forEach.call(appsMenuItems, function (el, i) {
			el.setAttribute("aria-expanded", "false");
		});
	});
	el.addEventListener("click", function (event) {
		if (
			this.getAttribute("aria-expanded") == "false" ||
			this.getAttribute("aria-expanded") == null
		) {
			this.setAttribute("aria-expanded", "true");
		} else {
			this.setAttribute("aria-expanded", "false");
		}
		// event.preventDefault();
		return false;
	});
	el.addEventListener("keydown", function (event) {
		var prevdef = false;
		switch (event.keyCode) {
			case keys.right:
				gotoIndex(currentIndex + 1);
				prevdef = true;
				break;
			case keys.left:
				gotoIndex(currentIndex - 1);
				prevdef = true;
				break;
			case keys.tab:
				if (event.shiftKey) {
					gotoIndex(currentIndex - 1);
				} else {
					gotoIndex(currentIndex + 1);
				}
				prevdef = true;
				break;
			case keys.enter:
			case keys.down:
				this.click();
				subindex = 0;
				gotoSubIndex(this.querySelector("ul"), 0);
				prevdef = true;
				break;
			case keys.up:
				this.click();
				var submenu = this.querySelector("ul");
				subindex = submenu.querySelectorAll("li").length - 1;
				gotoSubIndex(submenu, subindex);
				prevdef = true;
				break;
			case keys.esc:
				document.querySelector("#escape").setAttribute("tabindex", "-1");
				document.querySelector("#escape").focus();
				prevdef = true;
		}
		if (prevdef) {
			event.preventDefault();
		}
	});
});

Array.prototype.forEach.call(subMenuItems, function (el, i) {
	el.setAttribute("tabindex", "-1");
	el.addEventListener("keydown", function (event) {
		switch (event.keyCode) {
			case keys.tab:
				if (event.shiftKey) {
					gotoIndex(currentIndex - 1);
				} else {
					gotoIndex(currentIndex + 1);
				}
				prevdef = true;
				break;
			case keys.right:
				gotoIndex(currentIndex + 1);
				prevdef = true;
				break;
			case keys.left:
				gotoIndex(currentIndex - 1);
				prevdef = true;
				break;
			case keys.esc:
				gotoIndex(currentIndex);
				prevdef = true;
				break;
			case keys.down:
				gotoSubIndex(this.parentNode, subIndex + 1);
				prevdef = true;
				break;
			case keys.up:
				gotoSubIndex(this.parentNode, subIndex - 1);
				prevdef = true;
				break;
			case keys.enter:
			case keys.space:
				alert(this.innerText);
				prevdef = true;
				break;
		}
		if (prevdef) {
			event.preventDefault();
			event.stopPropagation();
		}
		return false;
	});
});
Array.prototype.forEach.call(appsMenuItems, function (el, i) {
	if (el.hasChildNodes().length < 1) {
		// It has at least one
		console.log("has chillde");
	}
	// ... (rest of the code remains the same)
});

document.addEventListener("DOMContentLoaded", function () {
	const searchButton = document.querySelector(".as-search-button");
	const searchForm = document.querySelector(".as-serch-form");
	const icon = document.querySelector(".as-search-button .fa");

	searchButton.addEventListener("click", function (e) {
		searchForm.classList.toggle("active");
		searchButton.classList.toggle("active");
		if (icon.classList.contains("fa-search")) {
			icon.classList.remove("fa-search");
			icon.classList.add("fa-close");
		} else {
			icon.classList.remove("fa-close");
			icon.classList.add("fa-search");
		}
	});
});
