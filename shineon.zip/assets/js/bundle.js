const $ = require("jquery");
import "./menu.js";

jQuery(document).ready(function ($) {
	// Replace '.your-button-selector' with the actual CSS selector for your button
	//$(".wp-block-navigation-submenu__toggle").removeAttr("aria-expanded");
	$(".wp-block-navigation-submenu__toggle").remove();

	$("ul > li.wp-block-navigation-submenu > a").each(function () {
		// Set the text content of the anchor to an empty string
		var anchor = $(this);
		anchor.replaceWith(anchor.contents());
	});
});

jQuery(document).ready(function ($) {
	$(".as-hover-col").hover(function () {
		$(".as-hover-col").removeClass("active");
		$(this).addClass("active");
	});

	$(".as-col-inner-box h2").on({
		mousemove: function (event) {
			$(".as-col-inner-box img").css({ top: event.pageY, left: event.pageX });
		},
		mouseenter: function () {
			$(".as-col-inner-box img").show();
		},
		mouseleave: function () {
			$(".as-col-inner-box img").hide();
		},
	});
});

var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
	acc[i].addEventListener("click", function () {
		this.classList.toggle("active");
		var panel = this.nextElementSibling;
		if (panel.style.display === "block") {
			panel.style.display = "none";
		} else {
			panel.style.display = "block";
		}
	});
}
