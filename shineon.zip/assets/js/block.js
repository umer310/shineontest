// import { registerBlockType } from "@wordpress/blocks";
// import { MediaUpload, InspectorControls } from "@wordpress/block-editor";
// import { PanelBody, Button } from "@wordpress/components";

// registerBlockType("your-namespace/background-image-column", {
// 	title: "Background Image Column",
// 	icon: "shield",
// 	category: "common",
// 	attributes: {
// 		backgroundImage: {
// 			type: "string",
// 			default: null,
// 		},
// 	},

// 	edit: function (props) {
// 		const { setAttributes, attributes } = props;

// 		const onSelectImage = (media) => {
// 			setAttributes({ backgroundImage: media.url });
// 		};

// 		return (
// 			<div>
// 				<InspectorControls>
// 					<PanelBody title="Background Image">
// 						<MediaUpload
// 							onSelect={onSelectImage}
// 							allowedTypes={["image"]}
// 							value={attributes.backgroundImage}
// 							render={({ open }) => (
// 								<Button onClick={open}>Select Image</Button>
// 							)}
// 						/>
// 					</PanelBody>
// 				</InspectorControls>
// 				{/* Your column content goes here */}
// 			</div>
// 		);
// 	},

// 	save: function () {
// 		// This is where you save the block content. Include the backgroundImage attribute.
// 		return null;
// 	},
// });
