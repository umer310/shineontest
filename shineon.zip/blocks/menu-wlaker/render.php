<?php

class Custom_Walker_Menu extends Walker_Nav_Menu
{
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $acf_icon = get_field('icon', $item);
        $field_type = get_field('fieldtype', $item->ID);
        $block_field = get_field('blocks', $item->ID);
        ob_start();
        $template_part_result = block_template_part('test');
        $template_part_result = ob_get_clean();

        if ($field_type == 'tab') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass my-tab ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
            if ($acf_icon) {
                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
            }

            $output .= esc_html($item->title);

            // Display the description for depth > 1
            if ($depth > 1 && !empty($description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= $block_content;
            $output .= '</a>';
        } else if ($field_type == 'with-out-link') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass with-out-link ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';

            if ($block_field == 'IconBlock') {
                $output .= esc_html($item->title);
                $output .= '<img src="http://shineon.test/wp-content/uploads/2023/10/icon-arrow-right.svg" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
                $output .= $block_content;
                $output .= '</a>';
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';

            } else {
                $output .= esc_html($item->title);

                $output .= $block_content;
                $output .= '</a>';

            }

        } else if ($field_type == 'block') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass block ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
            if ($acf_icon) {
                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
            }

            if ($block_field == 'StoriesBlock') {
                $output .= '<div class="menu-stories">';
                $output .= $template_part_result;
                $output .= '</div>';
            } else if ($block_field == 'PostBlock') {
                $output .= '<div class="menu-post-block">';
                //   $output .= $template_part_result;
                $output .= '</div>';
                $output .= '<span class="menu-item-description">This is a Post Block</span>';
                $output .= esc_html($item->title);
            } else if ($block_field == 'IconBlock') {
                $output .= '<div class="menu-icon-block">';
                $output .= '<img  src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
                $output .= '<span class="menu-item-description">This is an Icon Block</span>';
                $output .= esc_html($item->title);
                $output .= '</div>';
            } else if ($block_field == 'Simple') {
                $output .= '<span class="simple-menu-item">Simple Menu Item</span>';
            }

            $output .= esc_html($item->title);

            // Display the description for depth > 1
            if ($depth > 1 && !empty($description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= $block_content;
            $output .= '</a>';
        } else if ($field_type == 'heading') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass heading ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
            if ($acf_icon) {
                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
            }

            if ($block_field == 'StoriesBlock') {
                $output .= '<div class="menu-stories">';
                $output .= $template_part_result;
                $output .= '</div>';
            } else if ($block_field == 'PostBlock') {
                $output .= '<div class="menu-post-block">';
                //   $output .= $template_part_result;
                $output .= '</div>';
                $output .= '<span class="menu-item-description">This is a Post Block</span>';
                $output .= esc_html($item->title);
            } else if ($block_field == 'IconBlock') {
                $output .= '<div class="menu-icon-block">';
                $output .= '<img  src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
                $output .= '<span class="menu-item-description">This is an Icon Block</span>';
                $output .= esc_html($item->title);
                $output .= '</div>';
            } else if ($block_field == 'Simple') {
                $output .= '<span class="simple-menu-item">Simple Menu Item</span>';
            }

            $output .= esc_html($item->title);

            // Display the description for depth > 1
            if ($depth > 1 && !empty($description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= $block_content;
            $output .= '</a>';
        } else if ($field_type == 'link') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass link ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
            if ($acf_icon) {
                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
            }

            if ($block_field == 'StoriesBlock') {
                $output .= '<div class="menu-stories">';
                $output .= $template_part_result;
                $output .= '</div>';
            } else if ($block_field == 'PostBlock') {
                $output .= '<div class="menu-post-block">';
                //   $output .= $template_part_result;
                $output .= '</div>';
                $output .= '<span class="menu-item-description">This is a Post Block</span>';
                $output .= esc_html($item->title);
            } else if ($block_field == 'IconBlock') {
                $output .= '<div class="menu-icon-block">';
                $output .= '<img  src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
                $output .= '<span class="menu-item-description">This is an Icon Block</span>';
                $output .= esc_html($item->title);
                $output .= '</div>';
            } else if ($block_field == 'Simple') {
                $output .= '<span class="simple-menu-item">Simple Menu Item</span>';
            }

            $output .= esc_html($item->title);

            // Display the description for depth > 1
            if ($depth > 1 && !empty($description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= $block_content;
            $output .= '</a>';
        } else if ($field_type == 'link-and-tab') {
            // Add description for menu items with depth greater than 1
            $description = ($depth > 1) ? esc_html($item->description) : '';

            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass link-and-tab ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
            $output .= '>  ';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
            if ($acf_icon) {
                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
            }

            if ($block_field == 'StoriesBlock') {
                $output .= '<div class="menu-stories">';
                $output .= $template_part_result;
                $output .= '</div>';
            } else if ($block_field == 'PostBlock') {
                $output .= '<div class="menu-post-block">';
                //   $output .= $template_part_result;
                $output .= '</div>';
                $output .= '<span class="menu-item-description">This is a Post Block</span>';
                $output .= esc_html($item->title);
            } else if ($block_field == 'IconBlock') {
                $output .= '<div class="menu-icon-block">';
                $output .= '<img  src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
                $output .= '<span class="menu-item-description">This is an Icon Block</span>';
                $output .= esc_html($item->title);
                $output .= '</div>';
            } else if ($block_field == 'Simple') {
                $output .= '<span class="simple-menu-item">Simple Menu Item</span>';
            }

            $output .= esc_html($item->title);

            // Display the description for depth > 1
            if ($depth > 1 && !empty($description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= $block_content;
            $output .= '</a>';
        } else {
            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="  menu-item menu-item-' . esc_attr($item->ID) . " " . esc_attr($item->classes[0]) . '"';
            $output .= '>';

            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';

            // Display the description for depth > 1
            if ($depth > 1 && !empty($item->description)) {
                $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
            }

            $output .= esc_html($item->title);
            $output .= $block_content;
            $output .= '</a>';
        }
    }

    // public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    // {
    //     $acf_icon = get_field('icon', $item);
    //     $field_type = get_field('fieldtype', $item->ID);
    //     $block_field = get_field('blocks', $item->ID);
    //     ob_start();
    //     $template_part_result = block_template_part('test');
    //     $template_part_result = ob_get_clean();

    //     // Add description for menu items with depth greater than 1
    //     $description = ($depth > 1) ? esc_html($item->description) : '';

    //     $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
    //     $output .= ' class="myclass ' . esc_html($field_type) . ' ' . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . ' depth-' . $depth . '"';
    //     $output .= '>  ';

    //     $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
    //     if ($acf_icon) {
    //         $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
    //     }

    //     if ($block_field) {
    //         if ($block_field == 'StoriesBlock') {
    //             $output .= '<div class="menu-stories">' . $template_part_result . '</div>';
    //         } else if ($block_field == 'PostBlock') {
    //             $output .= '<div class="menu-post-block">';
    //             //   $output .= $template_part_result;
    //             $output .= '</div>';
    //             $output .= '<span class="menu-item-description">This is a Post Block</span>';
    //             $output .= esc_html($item->title);
    //         } else if ($block_field == 'IconBlock') {
    //             $output .= '<div class="menu-icon-block">';
    //             $output .= '<img  src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
    //             $output .= '<span class="menu-item-description">This is an Icon Block</span>';
    //             $output .= esc_html($item->title);
    //             $output .= '</div>';
    //         } else if ($block_field == 'Simple') {
    //             $output .= '<span class="simple-menu-item">Simple Menu Item</span>';
    //         }
    //     }

    //     $output .= esc_html($item->title);

    //     // Display the description for depth > 1
    //     if ($depth > 1 && !empty($description)) {
    //         $output .= '<span class="menu-item-description">' . esc_html($item->description) . '</span>';
    //     }

    //     $output .= $block_content;
    //     $output .= '</a>';
    // }

    // public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    // {
    //     // Check if the menu item depth is greater than one

    //     $acf_icon = get_field('icon', $item);
    //     $field_type = get_field('fieldtype', $item->ID);
    //     $block_field = get_field('blocks', $item->ID);
    //     ob_start();
    //     $template_part_result = block_template_part('test');
    //     $template_part_result = ob_get_clean();
    //     if ($field_type) {

    //         // echo '<pre> ';
    //         // var_dump($block_field);

    //         // echo ' </pre>';
    //         //die();
    //         $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
    //         $output .= ' class="myclass my-tab ' . $field_type . " " . esc_attr($item->classes[0]) . '   menu-item menu-item-' . esc_attr($item->ID) . " " . 'depth-' . $depth . '"';
    //         $output .= '>  ';
    //     } else {

    //         $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
    //         $output .= ' class="  menu-item menu-item-' . esc_attr($item->ID) . " " . esc_attr($item->classes[0]) . '"';
    //         $output .= '>';
    //     }

    //     $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';
    //     if ($acf_icon) {

    //         $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon ' . esc_html($field_type) . '" />';
    //     }
    //     if ($block_field == 'StoriesBlock') {

    //         $output .= '<div class="menu-stories"> ';
    //         $output .= $template_part_result;

    //         $output .= ' </div>';

    //     }

    //     $output .= esc_html($item->title);
    //     $output .= $block_content;
    //     $output .= '</a>';

    // }
}
?>

<nav id="appmenu" class="main-navigation">
    <?php
wp_nav_menu(array(
    'theme_location' => 'primary-menu', // Replace with your menu location name
    'menu_class' => 'header-menu', // Optional CSS class for the menu
    'container' => false, // Remove the outer <div> container
    'walker' => new Custom_Walker_Menu(), // Specify the custom walker class
));
?>
</nav>
<?php