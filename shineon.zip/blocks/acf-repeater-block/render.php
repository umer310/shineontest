<?php

/**
* Registers all block assets using metadata stored in `block.json`.
*/

function mytheme_register_acf_repeater_block() {

    // Path to the directory containing the block.json file
    $dir = get_template_directory() . '/path/to/your/block/directory/';

    $metadata = json_decode( file_get_contents( $dir . 'block.json' ), true );

    $metadata[ 'render_callback' ] = 'mytheme_render_acf_repeater_block';

    register_block_type_from_metadata( $dir, $metadata );

}

add_action( 'init', 'mytheme_register_acf_repeater_block' );

/**
* Render callback for the dynamic block.
*/

function mytheme_render_acf_repeater_block( $block ) {

    // Ensure we're getting data from the current post 
    $post_id = get_the_ID();

    // Start output bufferring
    ob_start();

    if(have_rows('points_boxs', $post_id)):
        
        echo "<div class = 'mytheme-acf-repeater-block'>";
        
        while(have_rows('points_boxs', $post_id)): the_row();
            
            $image = get_sub_field('points_box_image');
            $heading = get_sub_field('points_box_heading');
            $details = get_sub_field('points_details');
            
            echo "<div class = 'repeater-row'>";
            
            echo '<img src = "' . esc_url($image['url']) . '" alt = "' . esc_attr($image['alt']) . '" />';
            echo '<h2>' . esc_html($heading) . '</h2>';
            echo '<p>' . esc_html($details) . '</p>';
            
            echo '</div>';
            
        endwhile;
        
        echo '</div>';

    endif;

    // Return output as a string
    return ob_get_clean();
}