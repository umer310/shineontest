<?php
// get ACF fields data
global $post;
$service = get_field( 'service', get_the_ID() );
$industry = get_field( 'industry', get_the_ID() );
$energy_savings = get_field( 'energy_savings', get_the_ID() );
$payback_period = get_field( 'payback_period', get_the_ID() );
$annual_savings = get_field( 'annual_savings', get_the_ID() );
$first_year_return_on_investment = get_field( 'first_year_return_on_investment', get_the_ID() );
$annual_co2_reduction = get_field( 'annual_co2_reduction', get_the_ID() );
$total_10_year_saving = get_field( 'total_10_year_saving', get_the_ID() );
$success_story_pdf = get_field( 'success_story_pdf', get_the_ID() );

// get ACF fields data
$service = get_field( 'service' );

$industry = get_field( 'industry' );

// and so on for your other ACF fields...

// get the taxonomy terms

$terms = get_the_terms( $post->ID, 'stories-categories' );
$terms_industry= get_the_terms( $post->ID, 'industry' );

// Display block with ACF fields
echo '<div class="wp-block-trems-lists">';
if ( $terms && !is_wp_error( $terms ) ) {

    foreach ( $terms as $term ) {
        echo '<div class="wp-block-trems-list"> <img src="http://shineon.test/wp-content/uploads/2023/09/Lightbulb-1.svg"/>
        <p> <span>Service:</span>' . $term->name . '</p></div>';
    }

}
if ( $terms && !is_wp_error( $terms_industry ) ) {

    foreach ( $terms_industry as $term ) {
        echo '<div class="wp-block-trems-list"> <img src="http://shineon.test/wp-content/uploads/2023/09/ShineOn-Illustrative-Icon-Industrial.svg"/>
        <p> <span>Industry: </span>' . $term->name . '</p></div>';
    }

}


echo '</div>';
?>
<div class="wp-block-acf-lists">

    <?php
// Display block with ACF fields
if($service){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/Lightbulb-1.svg" />
        <div class="inner-content">
            <h4>serviecs</h4>
            <p><?php   echo esc_html($service);?> </p>
        </div>
    </div>
    <?php } 

if($industry){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/Lightbulb-1.svg" />
        <div class="inner-content">
            <h4>Industry</h4>
            <p><?php echo esc_html($industry);?> </p>
        </div>
    </div>
    <?php } 
if($energy_savings){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/Snowflake.svg" />
        <div class="inner-content">
            <h4>Energy Savings </h4>
            <p><?php echo esc_html($energy_savings);?> </p>
        </div>
    </div>
    <?php }
    if($payback_period){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/Scissors.svg" />
        <div class="inner-content">
            <h4> payback period </h4>
            <p><?php echo esc_html($payback_period);?> </p>
        </div>
    </div>
    <?php }
         if($annual_savings){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/MoneyBag.svg" />
        <div class="inner-content">
            <h4>Annual Savings :</h4>
            <p><?php echo esc_html($annual_savings);?> </p>
        </div>
    </div>
    <?php }
            if($first_year_return_on_investment){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/Handsleaf.svg" />
        <div class="inner-content">
            <h4> first year return on investment</h4>
            <p><?php echo esc_html($first_year_return_on_investment);?> </p>
        </div>
    </div>
    <?php } 
                  if($annual_co2_reduction){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/WorldPlant.svg" />
        <div class="inner-content">
            <h4>
                Annual co2 Reduction</h4>
            <p><?php echo esc_html($annual_co2_reduction);?> </p>
        </div>
    </div>
    <?php } 
                   if($total_10_year_saving){?>
    <div class="wp-block-acf-list">
        <img src="http://shineon.test/wp-content/uploads/2023/09/SolarExport.svg" />
        <div class="inner-content">
            <h4>
                Total 10 Year Saving</h4>
            <p><?php echo esc_html($total_10_year_saving);?> </p>
        </div>
    </div>
    <?php } ?>



</div>
<?php
  if (!empty($success_story_pdf)) {
    echo '<div class="is-style-outline as-class-center"> <a class="wp-block-button__link wp-element-button" href="' . esc_url($success_story_pdf) . '" download>Download Success Story</a> </div>';
}
?>