<?php

$block           = $block ?? [];
 
// Create class attribute allowing for custom "className" and "align" values.
$block_classname= 'wp-block-acf-test-acf-json-block';
if( !empty($block['className']) ) {
    $block_classname .= ' ' . $block['className'];
}

printf( '<div class="%s">', $block_classname );
printf( '<h3 class="message-text">%s</h3><div class="message-text-area">%s</div>',
	'This is message title text',
	'This is message text area field and should be replaced with actual ACF fields for the block'
);
printf( '</div>' );