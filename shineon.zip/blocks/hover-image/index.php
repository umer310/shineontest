<?php // silence is gold
