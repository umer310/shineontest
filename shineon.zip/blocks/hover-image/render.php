<?php

// get image field (array)
$img = get_field('hover_image');

// Create class attribute allowing for custom "className" and "align" values.
$className = 'my-acf-block';
if( !empty($block['className']) ) {
    $className .= ' ' . $block['className'];
}
if( !empty($block['align']) ) {
    $className .= ' align' . $block['align'];
}

 ?>
<div class="<?php echo esc_attr($className); ?>">
    <img class="my-block-image" src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['alt']); ?>" />
    <p class="my-block-text"><?php the_field('hover_text'); ?></p>
</div>