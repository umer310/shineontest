<?php
/**
* Custom Block for the Gutenberg.
*/

// Create id attribute allowing for custom 'anchor' value.
$id = 'custom-block-' . $block[ 'id' ];
if ( !empty( $block[ 'anchor' ] ) ) {
    $id = $block[ 'anchor' ];
}

// Create class attribute allowing for custom 'class_name' and 'align' values.
$className = 'custom-block';
if ( !empty( $block[ 'class_name' ] ) ) {
    $className .= ' ' . $block[ 'class_name' ];
}
if ( !empty( $block[ 'align' ] ) ) {
    $className .= ' align' . $block[ 'align' ];
}

$points_heading = get_field( 'points_heading', get_the_ID() );
$points_details = get_field( 'points_details', get_the_ID() );
?>

<div id = "<?php echo esc_attr($id); ?>" class = "<?php echo esc_attr(
    $className
); ?>">
<h2> <?php echo esc_html( $points_heading );
?></h2>
<div><?php echo esc_html( $points_details );
?></div>
</div>