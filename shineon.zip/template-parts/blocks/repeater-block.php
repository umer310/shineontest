<?php
/**
* Custom ACF Gutenberg Block for Repeater Fields.
*/

// Create id attribute allowing for custom 'anchor' value.
$id = 'repeater-block-' . $block[ 'id' ];
if ( !empty( $block[ 'anchor' ] ) ) {
    $id = $block[ 'anchor' ];
}

// Create class attribute allowing for custom 'class_name' and 'align' values.
$className = 'repeater-block';
if ( !empty( $block[ 'className' ] ) ) {
    $className .= ' ' . $block[ 'className' ];
}
if ( !empty( $block[ 'align' ] ) ) {
    $className .= ' align' . $block[ 'align' ];
}
?>
<?php

// Retrieve the repeater field
// blokki_render_card( the_post()->id );
?>

<div id="<?php echo esc_attr($id); ?>"
    class="<?php echo esc_attr($className); ?> wp-block-blokki-grid wp-block-blokki-grid blokki-grid large-up-5 medium-up-3 small-up-1 blokki-grid-gap-medium is-style-default">
    <?php

// Get the current post's ID.
$current_post_id = get_the_ID();

// Get the terms (categories) associated with the current post in the "industries-category" taxonomy.
$terms = wp_get_post_terms($current_post_id, 'industries-category');

// Check if there are any terms.
if (!empty($terms)) {
  // Extract the first term (you can modify this logic to handle multiple terms).
  $current_term = array_shift($terms);

  // Query related posts based on the current term.
  $args = array(
    'post_type' => 'industries', // Replace 'post' with your custom post type if needed.
    
    'orderby' => 'date', // Order related posts by date.
    'order' => 'DESC', // Display related posts in descending order (newest first).
    'tax_query' => array(
      array(
        'taxonomy' => 'industries-category',
        'field' => 'slug',
        'terms' => $current_term->slug, // Use the slug of the current term.
      ),
    ),
    'post__not_in' => array($current_post_id), // Exclude the current post from the related posts.
  );

  $related_query = new WP_Query($args);

  if ($related_query->have_posts()) {
    while ($related_query->have_posts()) {
      $related_query->the_post();
      blokki_render_card( get_the_ID() );
   
     // the_title();
     
    }

    // Restore the global post data.
    wp_reset_postdata();
  } else {
    // No related posts found.
    echo 'No related posts found.';
  }
}
?>

</div>