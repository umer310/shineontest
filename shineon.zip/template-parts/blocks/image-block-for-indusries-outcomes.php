<?php
/**
* Custom Block for the Gutenberg.
*/

// Create id attribute allowing for custom 'anchor' value.
$id = 'image-block-' . $block[ 'id' ];
if ( !empty( $block[ 'anchor' ] ) ) {
    $id = $block[ 'anchor' ];
}

// Create class attribute allowing for custom 'class_name' and 'align' values.
$className = 'image-block';
if ( !empty( $block[ 'class_name' ] ) ) {
    $className .= ' ' . $block[ 'class_name' ];
}
if ( !empty( $block[ 'align' ] ) ) {
    $className .= ' align' . $block[ 'align' ];
}

$image = get_field( 'outcome_side_image', get_the_ID() );
?>

<div id = "<?php echo esc_attr($id); ?>" class = "<?php echo esc_attr(
    $className
); ?>">
<?php

if ( $image ) : ?>
<img src = "<?php echo esc_url($image['url']); ?>" alt = "<?php echo esc_html($image['alt']); ?>" />
<?php endif;
?>
</div>