<?php
/**
* Custom ACF Gutenberg Block for Repeater Fields.
*/

// Create id attribute allowing for custom 'anchor' value.
$id = 'repeater-block-out-comes-' . $block[ 'id' ];
if ( !empty( $block[ 'anchor' ] ) ) {
    $id = $block[ 'anchor' ];
}

// Create class attribute allowing for custom 'class_name' and 'align' values.
$className = 'repeater-block-out-comes';
if ( !empty( $block[ 'className' ] ) ) {
    $className .= ' ' . $block[ 'className' ];
}
if ( !empty( $block[ 'align' ] ) ) {
    $className .= ' align' . $block[ 'align' ];
}
?>
<?php
// Retrieve the repeater field
if ( have_rows( 'out_comes', get_the_ID() ) ) :
?>

<div id = "<?php echo esc_attr($id); ?>" class = "<?php echo esc_attr($className); ?>">
<?php
while( have_rows( 'out_comes', get_the_ID() ) ): the_row();

$heading = get_sub_field( 'outcome_heading' );
$details = get_sub_field( 'outcome_details' );

// I assume this is an image field returning an array
?>
<div class = 'wp-block-blokki-content-accordion  '>
<button class = 'accordion'>

<?php echo esc_html( $heading );
?>

</button>
<p class = 'panel'>
<?php echo esc_html( $details );
?>
</p>
</div>
<?php endwhile;
?>
</div>

<?php endif;
?>