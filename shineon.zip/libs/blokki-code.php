<?php

function briks_blokki_post_type_customer_industries( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,

            'partials'           => array(
                'image',
                'inner' => array(

                    'title',
                    'excerpt',

                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_industries', 'briks_blokki_post_type_customer_industries' );

function briks_blokki_post_type_customer_partners( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,

            'partials'           => array(
                'image',
                'inner' => array(

                    // 'title',
                    // 'excerpt',
                    // 'readmore',
                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_partners', 'briks_blokki_post_type_customer_partners' );

function briks_blokki_post_type_stories( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => false,
            'show_taxonomy'      => true,

            'taxonomy'       => 'stories-categories',

            'partials'           => array(
                'image',
                'inner' => array(

                    'meta' => array(
                        'taxonomy',

                    ),
                    'title',
                    'acf-archive',

                )
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_stories', 'briks_blokki_post_type_stories' );

add_filter( 'blokki_get_post_type_config_partners', 'briks_blokki_post_type_customer_partners' );

function briks_blokki_post_type_post( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,
            'taxonomy'       => 'category',
            'partials'           => array(
                'image',
                'inner' => array(
                    'meta' => array(

                        'date', 'taxonomy',
                        'author',
                    ),
                    'title',

                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_post', 'briks_blokki_post_type_post' );

function briks_blokki_post_type_services( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,
            'taxonomy'       => 'category',
            'partials'           => array(
                'image',
                'inner' => array(
                    'title',
                    'excerpt',
                    'readmore'

                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_services', 'briks_blokki_post_type_services' );

function briks_blokki_post_type_page( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,
            'taxonomy'       => 'pages-category',
            'partials'           => array(
                'image',
                'inner' => array(
                     
                    'title',
                    'excerpt',

                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config_page', 'briks_blokki_post_type_page' );



function briks_blokki_post_type( $post_type_config ) {
    $post_type_config = array_merge(
        $post_type_config,
        array(
            'show_meta'          => true,
            'show_excerpt'       => true,
            'show_readmore'      => true,
            'image_size'         => 'medium_large',
            'link_card'          => true,
            'link_image'         => true,
            'link_title'         => true,
            'title_skip_tab'     => false,
            'link_taxonomy'      => true,
            'taxonomy'       => 'pages-category',
            'partials'           => array(
                'image',
                'inner' => array(
                     
                    'title',
                    'excerpt',
                    'readmore'

                ),
            ),
        )
    );

    return $post_type_config;
}

add_filter( 'blokki_get_post_type_config', 'briks_blokki_post_type' );