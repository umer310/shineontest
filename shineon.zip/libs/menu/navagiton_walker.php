<?php

class ACF_Walker_Nav_Menu extends Walker_Nav_Menu
{
    // Customize how menu items are displayed, including ACF field output
    // See ACF documentation for details on retrieving and displaying field data

    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        // Check if the menu item depth is greater than one
        if ($depth = 1) {
            $acf_icon = get_field('icon', $item);
            $field_value = get_field('field_type', $item->ID);
            $output .= '<li id="menu-item' . esc_attr($item->ID) . '"';
            $output .= ' class="myclass menu-item menu-item-' . esc_attr($item->ID) . '"';
            $output .= '>';
            $output .= '<a href="' . esc_url($item->url) . '" class="menu-link">';

            if ($acf_icon && $field_value) {

                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon tab ' . esc_html($field_value) . '" />';
            } else if ($acf_icon) {

                $output .= '<img src="' . esc_url($acf_icon['url']) . '" alt="' . esc_attr($item->title) . '" class="menu-icon" />';
            }

            $output .= esc_html($item->title);
            $output .= '</a>';
        } else {
            // If the depth is not greater than one, handle it differently or skip it as needed
            // For example, you can add different markup or do nothing.
        }
    }

}
// wp_nav_menu(array(
//     'theme_location' => 'primary-menu', // Use the correct menu location slug
//     'walker' => new Walker_Nav_Menu(),
//     ));
