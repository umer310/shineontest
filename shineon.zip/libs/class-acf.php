<?php
 
// class My_Block_Setup {
//     private $block_folder_path;

//     public function __construct() {
//         $this->block_folder_path = get_template_directory() . '/blocks'; 
//         add_action('init', array($this, 'register_blocks'));
//         add_action('acf/init', array($this, 'add_option_pages'));
//     }
    
//     public function register_blocks() {
        
//         // if function doesn't exist, exit
//         if (!function_exists('register_block_type_from_metadata')) return;

//         // get blocks directory
//         $blocks_dir = get_template_directory() . '/blocks';

//         // array of block json files
//         $block_json_files = glob($blocks_dir . '/*/block.json');

//         // loop through json files
//         foreach($block_json_files as $json_file) {

//         // register block using metadata from block.json
//         $metadata = json_decode(file_get_contents($json_file), true);
//         $metadata['render_callback'] = 'your_theme_test_block_render_callback';
//         $block = register_block_type_from_metadata($blocks_dir . '/' . basename(dirname($json_file)), $metadata);
//         }
//     }
    
//     public function add_option_pages() {
//         // Check function exists
//         if( function_exists('acf_add_options_page') ) {
//             // Add parent option page
//             $parent = acf_add_options_page(array(
//                 'page_title' => 'Theme General Settings',
//                 'menu_title' => 'Theme Settings'
//             ));
            
//             // Add sub-option pages
//             acf_add_options_sub_page(array(
//                 'page_title' => 'Header Settings',
//                 'menu_title' => 'Header',
//                 'parent_slug' => $parent['menu_slug']
//             ));
//         }
//     }
// }
class My_Block_Setup {
    private $block_folder_path;

    public function __construct() {
        $this->block_folder_path = get_template_directory() . '/blocks'; 
        add_action('init', array($this, 'register_blocks'));
        add_action('acf/init', array($this, 'add_option_pages'));
    }
    
    public function register_blocks() {
        
        // if function doesn't exist, exit
        if (!function_exists('register_block_type_from_metadata')) return;

        // get blocks directory
        $blocks_dir = get_template_directory() . '/blocks';

        // array of block json files
        $block_json_files = glob($blocks_dir . '/*/block.json');

        // loop through json files
        foreach($block_json_files as $json_file) {

        // register block using metadata from block.json
        $metadata = json_decode(file_get_contents($json_file), true);
        $metadata['render_callback'] = 'your_theme_test_block_render_callback';
        $block = register_block_type_from_metadata($blocks_dir . '/' . basename(dirname($json_file)), $metadata);
        }
    }
    
    public function add_option_pages() {
        // Check function exists
        if( function_exists('acf_add_options_page') ) {
            // Add parent option page
            $parent = acf_add_options_page(array(
                'page_title' => 'Theme General Settings',
                'menu_title' => 'Theme Settings'
            ));
            
            // Add sub-option pages
            acf_add_options_sub_page(array(
                'page_title' => 'Header Settings',
                'menu_title' => 'Header',
                'parent_slug' => $parent['menu_slug']
            ));
        }
    }
}

 
new My_Block_Setup();

 
// Define the block
function custom_acf_block_render() {
    // Fetch ACF field values
    $acfField1 = get_field('acf_field_1');
    $acfField2 = get_field('acf_field_2');

    // Output the block content
    $output = '<div class="custom-acf-block">';
    $output .= '<p>ACF Field 1: ' . esc_html($acfField1) . '</p>';
    $output .= '<p>ACF Field 2: ' . esc_html($acfField2) . '</p>';
    $output .= '</div>';

    return $output;
}

// Register the block
function register_custom_acf_block() {
    register_block_type('custom-acf-block', array(
        'render_callback' => 'custom_acf_block_render',
    ));
}
add_action('init', 'register_custom_acf_block');