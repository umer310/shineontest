const gulp = require("gulp");
const plumber = require("gulp-plumber");
const sass = require("gulp-sass")(require("sass"));
const babel = require("gulp-babel");
const yargs = require("yargs");
const cleanCSS = require("gulp-clean-css");
const gulpIf = require("gulp-if");
const sourcemaps = require("gulp-sourcemaps");
const webpack = require("webpack-stream");
const uglify = require("gulp-uglify");
const named = require("vinyl-named");

const zip = require("gulp-zip");
const replace = require("gulp-replace");
const info = require("./package.json");

const PRODUCTION = yargs.alias("production");
const wpPot = require("gulp-wp-pot");

const path = {
	styles: {
		src: ["assets/scss/bundle.scss", "assets/scss/admin.scss "],
		dest: "dist/src/css",
	},
	fonts: {
		src: ["assets/fonts/*"],
		dest: ["dist/fonts"],
	},
	scrpit: {
		src: [
			"assets/js/bundle.js",
			"assets/js/admin.js",
			"assets/js/customize-preview.js",
			"assets/js/block-variation.js",
		],
		dest: "dist/src/js",
	},
	plugins: {
		src: [
			"../../plugins/_themename-metaboxes/packaged/*",
			"../../plugins/_themename-shortcodes/packaged/*",
			"../../plugins/_themename-post-type/packaged/*",
		],
		dest: "lib/plugins",
	},
	zip: {
		src: [
			"**/*",
			"!.vscode",
			"!node_modules{,/**}",
			"!packaged{,/**}",
			"!assets{,/**}",
			"!node_modules/*",
			"!package",
			"!node_modules",
			"!.baelrc",
			"!gitignore",
			"!gulpfile.js",
			"!package.json",
			"!package-lock.json",
		],
		dest: "dist",
	},
};

gulp.task("pot", function () {
	return gulp
		.src("**/*.php")
		.pipe(
			wpPot({
				domain: "_themename",
				package: info.name,
			})
		)
		.pipe(gulp.dest(`language/${info.name}.pot`));
});

gulp.task("scss", function () {
	return gulp
		.src(path.styles.src) // Replace with the path to your SCSS files
		.pipe(gulpIf(!PRODUCTION, sourcemaps.init())) // Copy
		.pipe(sass().on("error", sass.logError))
		.pipe(gulpIf(PRODUCTION, cleanCSS({ compatibility: "ie8" })))
		.pipe(gulpIf(!PRODUCTION, sourcemaps.write()))
		.pipe(gulp.dest(path.styles.dest)); // Replace with the destination directory for the compiled CSS files
});
gulp.task("fonts", function () {
	return gulp
		.src(path.fonts.src)
		.pipe(plumber())
		.pipe(gulp.dest(path.fonts.dest));
});

const isProduction = process.env.NODE_ENV === "production";
gulp.task("webpack", function () {
	return gulp
		.src(path.scrpit.src) // Replace with the entry file of your application
		.pipe(named())
		.pipe(
			webpack({
				mode: isProduction ? "production" : "development", // Set to 'development' for non-minified output
				devtool: "inline-source-map",
				output: {
					filename: "[name].js", // Replace with the desired output file name
				},
				externals: {
					jquery: "jQuery",
				},
				module: {
					rules: [
						{
							test: /\.js$/,
							exclude: /node_modules/,
							use: {
								loader: "babel-loader",
								options: {
									presets: ["@babel/preset-env", "@babel/preset-react"],
								},
							},
						},
					],
				},
				optimization: {
					minimize: isProduction,
					minimizer: [uglify],
				},
			})
		)
		.pipe(gulpIf(PRODUCTION, uglify()))
		.pipe(gulp.dest(path.scrpit.dest));
	// Replace with the destination directory for the transpiled JS files
});

gulp.task("watch", function () {
	// gulp.task("plugins", function () {
	// 	return gulp.src(path.plugins.src).pipe(gulp.dest(path.plugins.dest));
	// });

	gulp.watch("assets/scss/**/*.scss", gulp.series("scss"));
	gulp.watch("assets/fonts/*", gulp.series("fonts"));
	gulp.watch("assets/js/**/*.js", gulp.series("webpack"));
});
gulp.task("zip", function () {
	return gulp
		.src(path.zip.src)
		.pipe(
			gulpIf(
				(file) => file.relative.split(".").pop() !== "zip",
				replace("_themename", info.name)
			)
		)
		.pipe(zip(`${info.name}.zip`))
		.pipe(gulp.dest(path.zip.dest));
});

gulp.task("build", gulp.series("pot", "zip"));
gulp.task("default", gulp.series("fonts", "scss", "webpack", "watch"));
