<?php
$service                         = get_field( 'service', get_the_ID() );
$industry                        = get_field( 'industry', get_the_ID() );
$energy_savings                  = get_field( 'energy_savings', get_the_ID() );
$payback_period                  = get_field( 'payback_period', get_the_ID() );
$annual_savings                  = get_field( 'annual_savings', get_the_ID() );
$first_year_return_on_investment = get_field( 'first_year_return_on_investment', get_the_ID() );
$annual_co2_reduction            = get_field( 'annual_co2_reduction', get_the_ID() );
$total_10_year_saving            = get_field( 'total_10_year_saving', get_the_ID() );
$annual_co2_reduction            = get_field( 'annual_co2_reduction', get_the_ID() );
$first_year_return_on_investment = get_field( 'first_year_return_on_investment', get_the_ID() );

$fields = array(
    'service' => 'Service',
    'industry' => 'Industry',
    'energy_savings' => 'Energy Savings',
    'payback_period' => 'Payback Period',
    'annual_savings' => 'Annual Savings',
    'first_year_return_on_investment' => 'First Year ROI',
    'annual_co2_reduction' => 'Annual CO2 Reduction',
    'total_10_year_saving' => 'Total 10-Year Saving'
);

// Check if any of the fields have values
$hasValues = false;
foreach ( $fields as $fieldKey => $fieldName ) {
    $fieldValue = get_field( $fieldKey, get_the_ID() );
    if ( !empty( $fieldValue ) ) {
        $hasValues = true;
        break;
        // Exit loop if any field has a value
    }
}

if ( $hasValues ) {
    echo '<table class="acf-table">';
    foreach ( $fields as $fieldKey => $fieldName ) {
        $fieldValue = get_field( $fieldKey, get_the_ID() );
        if ( !empty( $fieldValue ) ) {
            echo '<tr>';
            echo '<td class="field-name">' . esc_html( $fieldName ) . ':</td>';
            echo '<td class="field-value">' . esc_html( $fieldValue ) . '</td>';
            echo '</tr>';
        }
    }
    echo '</table>';
}