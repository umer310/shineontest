<?php
/**
* Functions and definitions
*
* @link https://developer.wordpress.org/themes/basics/theme-functions/
*
* @package shineon
* @since 1.0.0
*/

/**
* The theme version.
*
* @since 1.0.0
*/
define( 'SHINEON_VERSION', wp_get_theme()->get( 'Version' ) );

/**
* Add theme support for block styles and editor style.
*
* @since 1.0.0
*
* @return void
*/

function shineon_setup() {
    add_editor_style( './assets/css/style-shared.min.css' );

    /*
    * Load additional block styles.
    * See details on how to add more styles in the readme.txt.
    */
    $styled_blocks = [ 'button', 'quote', 'navigation' ];
    foreach ( $styled_blocks as $block_name ) {
        $args = array(
            'handle' => "shineon-$block_name",
            'src'    => get_theme_file_uri( "assets/css/blocks/$block_name.min.css" ),
            'path'   => get_theme_file_path( "assets/css/blocks/$block_name.min.css" ),
        );
        // Replace the 'core' prefix if you are styling blocks from plugins.
        wp_enqueue_block_style( "core/$block_name", $args );
    }

}
add_action( 'after_setup_theme', 'shineon_setup' );

/**
* Enqueue the CSS files.
*
* @since 1.0.0
*
* @return void
*/
// function shineon_styles() {
// 	wp_enqueue_style(
// 		'shineon-style',
// 		get_stylesheet_uri(),
// 		[],
// 		SHINEON_VERSION
// 	 );
// 	wp_enqueue_style(
// 		'shineon-shared-styles',
// 		get_theme_file_uri( 'assets/css/style-shared.min.css' ),
// 		[],
// 		SHINEON_VERSION
// 	 );
// }
// add_action( 'wp_enqueue_scripts', 'shineon_styles' );

// Filters.
require_once get_theme_file_path( 'inc/filters.php' );

// Block variation example.
require_once get_theme_file_path( 'inc/register-block-variations.php' );

// Block style examples.
require_once get_theme_file_path( 'inc/register-block-styles.php' );

// Block pattern and block category examples.
require_once get_theme_file_path( 'inc/register-block-patterns.php' );

// asstes file includies.
require_once get_theme_file_path( 'libs/enqueue-assets.php' );
// asstes file includies.
require_once get_theme_file_path( 'libs/theme-support.php' );
// blokki code for developemt of blokki card file includies.
require_once get_theme_file_path( 'libs/blokki-code.php' );


require_once get_theme_file_path( 'libs/class-acf.php' );
//ACF Walker class
 require_once get_theme_file_path( 'libs/menu/navagiton_walker.php' );
 



add_action( 'acf/init', 'register_acf_blocks' );

function register_acf_blocks() {

    // Check if function exists.
    if ( function_exists( 'acf_register_block_type' ) ) {

        // register a new block.
        acf_register_block_type( array(
            'name'              => 'custom_block',
            'title'             => __( 'Custom block' ),
            'description'       => __( 'A custom block.' ),
            'render_template'   => 'template-parts/blocks/custom-block.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'keywords'          => array( 'custom', 'block' ),
        ) );
    }
}

add_action( 'acf/init', 'register_acf_blocks_repater' );

function register_acf_blocks_repater() {
    if ( function_exists( 'acf_register_block_type' ) ) {
        acf_register_block_type( array(
            'name'              => 'repeater_block',
            'title'             => __( 'Repeater Block' ),
            'description'       => __( 'A custom repeater block.' ),
            'render_template'   => 'template-parts/blocks/repeater-block.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'keywords'          => array( 'repeater', 'block' ),
        ) );
    }
}

add_action( 'acf/init', 'register_acf_blocks_repater_out_comes' );

function register_acf_blocks_repater_out_comes() {
    if ( function_exists( 'register_acf_blocks_repater_out_comes' ) ) {
        acf_register_block_type( array(
            'name'              => 'repeater_block_out_comes',
            'title'             => __( 'Repeater Block' ),
            'description'       => __( 'A custom repeater block out comes.' ),
            'render_template'   => 'template-parts/blocks/repeater-block-out-comes.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'keywords'          => array( 'repeater', 'block' ),
        ) );
    }
}
add_action( 'acf/init', 'register_acf_blocks_out_comes_image_block' );

function register_acf_blocks_out_comes_image_block() {
    if ( function_exists( 'register_acf_blocks_repater_out_comes' ) ) {
        acf_register_block_type( array(
            'name'              => 'image_block',
            'title'             => __( 'image Block' ),
            'description'       => __( 'A custom image block.' ),
            'render_template'   => 'template-parts/blocks/image-block-for-indusries-outcomes.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'keywords'          => array( 'repeater', 'block' ),
        ) );
    }
}


add_action('acf/init', function() {
    // check function exists.
    if(function_exists('acf_register_block_type')) {
        // register block.
        acf_register_block_type([
            'name'              => 'my-acf-block',
            'title'             => __('My ACF Block'),
            'description'       => __('A custom block with ACF fields.'),
            'render_template'   => 'blocks/my-acf-block/render.php',
            'category'          => 'formatting',
            'icon'              => 'admin-comments',
            'keywords'          => ['acf']
        ]);
    }

    // This is where you would add ACF fields data here
});    

 